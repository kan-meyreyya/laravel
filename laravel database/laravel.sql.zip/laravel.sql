--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `medias`
--

CREATE TABLE `medias` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_size` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `file_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `medias`
--

INSERT INTO `medias` (`id`, `file_name`, `file_size`, `created_by`, `created_date`, `file_type`) VALUES
(23, '57e93a0d40844book.jpg', '14805', 60, '2016-09-26 15:09:01', 'image/jpeg'),
(24, '57e93f01c85d3testing.jpg', '19140', 60, '2016-09-26 15:30:09', 'image/jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `email` text,
  `password` varchar(100) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `remember_token` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`, `updated_at`, `status`, `remember_token`) VALUES
(60, 'kan meyreyya', 'yu.mengkhorng@gmail.com', '$2y$10$Q9X9bIMOtPFDq8IdnfBTLO0ueyH4pAhuZ0DlN1vHBLPy.GJ5mPOvy', 'administrator', '2016-09-22 09:18:46', '2016-09-23 04:21:19', 1, '4WTwQRBrJdL65knMweL3UqXVRCkM9hZGWcBecoz3YCkXv9Uu5u25bdINY9QD'),
(70, 'testing', 'example@gmail.com', '$2y$10$dxV6d8Jf8EOlnid6bX0dE.QLPIPGOmlmyPSvf7KQZJ0Y6pd5rqIru', 'administrator', '2016-09-23 04:25:19', '2016-09-23 07:29:18', 1, NULL),
(72, '2342423', 'kan.meyreyya@gmail.com', '$2y$10$BNOynrmbaKhCfmU.nbHfye9.1U6YB841eyQ8MT5Gd8/9KwfBynHK2', 'editor', '2016-09-23 07:32:44', NULL, 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medias`
--
ALTER TABLE `medias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `medias`
--
ALTER TABLE `medias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
