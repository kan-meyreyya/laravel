-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2016 at 12:06 PM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `medias`
--

CREATE TABLE IF NOT EXISTS `medias` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_size` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `file_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `medias`
--

INSERT INTO `medias` (`id`, `file_name`, `file_size`, `created_by`, `created_date`, `file_type`) VALUES
(2, '57e4f46b49998favorite-icon1.png', '1522', 72, '2016-09-23 09:22:51', 'image/png'),
(3, '57e4f6990c6f1favorite-icon1.png', '1522', 72, '2016-09-23 09:32:09', 'image/png'),
(4, '57e4f7ea98bb0images.jpg', '9586', 72, '2016-09-23 09:37:46', 'image/jpeg'),
(5, '57e4fa49173d7favorite-icon1.png', '1522', 72, '2016-09-23 09:47:53', 'image/png'),
(6, '57e4fbd04772bfavorite-icon1.png', '1522', 72, '2016-09-23 09:54:24', 'image/png'),
(7, '57e4fc7727b23cat.jpg', '329877', 72, '2016-09-23 09:57:11', 'image/jpeg'),
(8, '57e4fdb419558images.jpg', '9586', 72, '2016-09-23 10:02:28', 'image/jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `email` text,
  `password` varchar(100) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `remember_token` text
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`, `updated_at`, `status`, `remember_token`) VALUES
(60, 'kan meyreyya', 'yu.mengkhorng@gmail.com', '$2y$10$Q9X9bIMOtPFDq8IdnfBTLO0ueyH4pAhuZ0DlN1vHBLPy.GJ5mPOvy', 'administrator', '2016-09-22 09:18:46', '2016-09-23 04:21:19', 1, '4WTwQRBrJdL65knMweL3UqXVRCkM9hZGWcBecoz3YCkXv9Uu5u25bdINY9QD'),
(70, 'testing', 'example@gmail.com', '$2y$10$dxV6d8Jf8EOlnid6bX0dE.QLPIPGOmlmyPSvf7KQZJ0Y6pd5rqIru', 'administrator', '2016-09-23 04:25:19', '2016-09-23 07:29:18', 1, NULL),
(72, '2342423', 'kan.meyreyya@gmail.com', '$2y$10$BNOynrmbaKhCfmU.nbHfye9.1U6YB841eyQ8MT5Gd8/9KwfBynHK2', 'editor', '2016-09-23 07:32:44', NULL, 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medias`
--
ALTER TABLE `medias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `medias`
--
ALTER TABLE `medias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=73;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
